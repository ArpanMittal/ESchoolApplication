<?php

if (file_exists($autoload_file = __DIR__.'/../vendor/autoload.php')) {
    require_once $autoload_file;
}